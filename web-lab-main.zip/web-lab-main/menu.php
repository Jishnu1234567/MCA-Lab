<html>
    <head>
        <title>Menu</title>
    </head>
    <body>
        <center><h2>Menu</h2></center>
        <br>
        <a href="mainhome.php" target="right">Home</a><br>
        <br>
        <br>
        <a href="studreg.php" target="right">Register</a><br>
        <br>
        <br>
        <a href="mark.php" target="right">Mark</a><br>
        <br>
        <br>
        <a href="studsearch.php" target="right">View</a><br>
        <br>
        <br>
        <a href="studupdate.php" target="right">Update</a><br>
        <br>


    </body>
</html>