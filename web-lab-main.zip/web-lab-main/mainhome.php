<html>
    <head>
        <title>Home</title>
</head>
<body>
    <h1>Welcome</h1>
</body>
    </html>