<html>
    <head>
        <title>Home</title>
    </head>
    <frameset cols="30%,70%">
        <frame name="left" src="menu.php"/>
        <frame name="right" src="mainhome.php"/>
        <frame name="right" src="mark.php"/>
        <frame name="right" src="studreg.php"/>
        <frame name="right" src="studsearch.php"/>
        <frame name="right" src="studupdate.php"/>

        <noframes>
            <body>Browser has no frames</body>
</noframes>
</frameset>

</html>