<html>
    <head>
        <title>Home</title>
    </head>
    <body>
        <form action="studreg1.php" method="POST">
            <table border="0" cellspacing="10" cellpadding="10">
                <tr>
                    <td>Name : </td>
                    <td><input type="text" name="name"/></td>
                </tr>
                <tr>
                    <td>Roll No : </td>
                    <td><input type="text" name="rollno"/></td>
                </tr>
                <tr>
                    <td>KTU Id : </td>
                    <td><input type="text" name="ktuid"/></td>
                </tr>
                <tr>
                    <td>Gender : </td>
                    <td><input type="text" name="gender"/></td>
                </tr>
                <tr>
                    <td>Semester : </td>
                    <td><input type="text" name="semester"/></td>
                </tr>
                <tr>
                    
                    <td><input type="submit" name=/></td>
                </tr>
            </table>
        </form>
    </body>

   
</html>