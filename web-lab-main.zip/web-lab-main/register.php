<html>
<head>
<title>
    Register
</title>
</head>
<body>
<form action="login1.php" method="POST">
<h1>Register</h1>

<label>Name : </label>
<input type="Text" name="name" /><br>

<label>Email : </label>
<input type="Text" name="email" /><br>

<label>Phone : </label>
<input type="Text" name="phoneno" /><br>

<label>Password : </label>
<input type="password" name="pass" /><br>

<label>Re Type Password : </label>
<input type="password" name="repass" /><br>

<button type="Submit">Register</button><br>

<p>Already have an account? <a href="login.php">Log In</a></p><br>
</form>



</body>

</html>