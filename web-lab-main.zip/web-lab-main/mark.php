<html>
    <head>
        <title>Home</title>
    </head>
    <body>
        <form action="mark1.php" method="POST">
            <table border="0" cellspacing="10" cellpadding="10">
                <tr>
                    <td>Ktuid : </td>
                    <td><input type="text" name="ktuid"/></td>
                </tr>
                <tr>
                    <td>Series1 : </td>
                    <td><input type="text" name="series1"/></td>
                </tr>
                <tr>
                    <td>Series2 : </td>
                    <td><input type="text" name="series2"/></td>
                </tr>
                <tr>
                    <td>Assignment1 : </td>
                    <td><input type="text" name="assignment1"/></td>
                </tr>
                <tr>
                    <td>Assignment2 : </td>
                    <td><input type="text" name="assignment2"/></td>
                </tr>
                <tr>
                    <td>Attendance : </td>
                    <td><input type="text" name="attendance"/></td>
                </tr>
                <tr>
                    
                    <td><input type="submit" name=/></td>
                </tr>
            </table>
        </form>
    </body>

   
</html>