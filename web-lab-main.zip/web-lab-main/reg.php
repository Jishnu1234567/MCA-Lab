<html>
    <head>
        <title>program 3</title>
</head>
<body bgcolor = "sky blue">
    <form>
        <center><b1>Welcome To Freshers</b1></center>
        <table border = "/"cellpadding = "/"
        cellpadding = "/" align = "center">
        <td>
            <th colspan = "/" align = "center">
                registration form </th>
</tv>
</td>
namespace
</td>
<td>
    <input type = "text" name = "Name"/>
    <td>
</tr>
<tr>
    <td> age: </td>
    <td> <select>
        <option value = "18">18 </option>
        <option value = "19">19</option>
        <option value = "20">20</option>
        <option value = "21">21</option>
        <option value = "22">22</option>
        <option value = "23">23</option>
</select></td>
</tr>
<tr>
    <td>password:</td>
    <td><input type = "password"/>
</td>
</tr>
<tr>
    <td> Re-Enter Password :</td>
    <td><input type = "password"/></td>
</tr>
<tr>
    <td Crosspan = "5"> Select Your Security Question </td>
     <td>
        <tr>
            <td>
                <input type = "radio" name ="question"/>
                Who Is Your Best Friend
</td>
</tr>
<td>
    <input type = "radio" name = "question"/>
    What Is Your Favourite Color
</td>
</tr>
<tr><td>
    <input type = "radio" name = "question"/>
    Who Is Your Favourite Teacher:
</td></tr>
<tr>
    <td>Answer the security question : </td>
    <td><input type="Text" name="securityQ"/></td>
</tr>
<tr>
    <td>Email id : </td>
    <td><input type="Text" name="email"/></td>
</tr>
<tr>
    <td>Languages Know</td>
    <td><input type="Checkbox" />Malayalum<input type="Checkbox"/>English<input type="Checkbox"/>Hindi</td>
</tr>
<tr>
    <td rowspan="2">Phone number</td>
</tr>
<tr>
    <td>
        <table border="1">
            <tr>
                <th>Home</th>
                <th>Office</th>
            </tr>
            <tr>
                <td><input type="Text"/></td>
                <td><input type="Text" /></td>
            </tr>
        </table>
    </td>
</tr>

<tr>
    <td><label>Upload CV</label></td>
    <td><input type="File"/></td>
</tr>

<tr>
    <td align="center">
        <button type="reset">Reset</button>
    </td>
    <td align="center">
        <button type="submit">Submit</button>
    </td>
</tr>
</table>
</form>
</body>
</html>