<?php
$num=4;
$fact=1;
for($i=$num;$i>0;$i--)
{
$fact=$fact*$i;
}
echo "Factorial of $num is $fact";
?>