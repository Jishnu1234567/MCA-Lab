dict1 = {1:'Rahul', 2:'Gauthum', 3:'Suresh'}
dict2 = {3:'Hrithik',4:'Anu', 5:'Shrek'}

print(dict1 | dict2)