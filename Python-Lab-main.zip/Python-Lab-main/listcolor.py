color1 = input("Enter colors of list 1 : ").split(',')
print(color1)

pos1=[color1[0]]
print('First color of the list : ',pos1)
pos2=[color1[-1]]
print('Last color of the list : ',pos2)

