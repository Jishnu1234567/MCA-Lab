def rectanglearea(l,b):
    return l*b

def rectperimeter(l,b):
    return 2*(l+b)