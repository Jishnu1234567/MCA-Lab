def spherearea(r):
    return 4*3.14*r*r

def spherperimeter(r):
    return 2*3.14*r