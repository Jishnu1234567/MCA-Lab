def cuboidarea(l,b,h):
    return 2*((l*b)+(b*h)+(l*h))

def cuboidperimeter(l,b,h):
    return 4*(l*b*h)