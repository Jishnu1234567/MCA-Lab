#Rectangle  
r = lambda l,b: l*b 
print('Area of rectangle:',r(7,4)) 

#Square 
s = lambda a: a*a 
print('Area of square:',s(6)) 

#Triangle  
t = lambda h1,h2: 0.5*h1*h2
print('Area of triangle:',t(4,5)) 
  

